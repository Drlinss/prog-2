/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class DocenteContratoFijo extends Empleado {
    public DocenteContratoFijo(String nombre, double salarioBase) {
        super(nombre, salarioBase);
    }

    @Override
    public double calcularSalario(boolean alcanzoMeta) {
        return alcanzoMeta ? salarioBase : salarioBase / 2;
    }
}

