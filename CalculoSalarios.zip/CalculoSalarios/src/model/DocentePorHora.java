/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class DocentePorHora extends Empleado {
    private int horasTrabajadas;
    private static final double TARIFA_POR_HORA = 800;

    public DocentePorHora(String nombre, int horasTrabajadas) {
        super(nombre, 0); // salarioBase no aplica
        this.horasTrabajadas = horasTrabajadas;
    }

    @Override
    public double calcularSalario(boolean alcanzoMeta) {
        return horasTrabajadas * TARIFA_POR_HORA;
    }
}

