/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import model.*;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Empleado> empleados = new ArrayList<>();

        // Crear empleados
        empleados.add(new DocentePorHora("Juan", 40));
        empleados.add(new DocenteContratoFijo("Ana", 30000));
        empleados.add(new EmpleadoAdministrativo("Carlos", 25000));

        // Calcular y mostrar salarios
        for (Empleado empleado : empleados) {
            boolean alcanzoMeta = Math.random() > 0.5; // Simulación de meta alcanzada
            double salario = empleado.calcularSalario(alcanzoMeta);

            System.out.println("Empleado: " + empleado.getNombre());
            System.out.println("Salario: " + salario);
            System.out.println("¿Alcanzó la meta?: " + (alcanzoMeta ? "Sí" : "No"));
            System.out.println("--------------------------------");
        }
    }
}
