/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MSI
 */
package practicaoop;

public class Curso {
    private String nombre;
    private int recuentoClases;
    private int recuentoEjercicios;

    public Curso(String nombre, int recuentoClases, int recuentoEjercicios) {
        this.nombre = nombre;
        this.recuentoClases = recuentoClases;
        this.recuentoEjercicios = recuentoEjercicios;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return nombre + " (" + recuentoClases + " clases, " + recuentoEjercicios + " ejercicios)";
    }
}

