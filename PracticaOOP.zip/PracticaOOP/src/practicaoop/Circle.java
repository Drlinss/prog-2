/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author MSI
 */
package practicaoop;

public class Circle extends Shape {
    public Circle(double radio) {
        super(radio, radio);
    }

    @Override
    public double calcularArea() {
        return Math.PI * ancho * ancho;
    }
}

