/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MSI
 */
package practicaoop;

public class Main {
    public static void main(String[] args) {
        Shape[] figuras = {
            new Rectangle(5, 10),
            new Triangle(4, 8),
            new Circle(7)
        };

        for (Shape figura : figuras) {
            System.out.println("Área: " + figura.calcularArea());
        }
    }
}
