/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practicaoop;

public class Rectangle extends Shape {
    public Rectangle(double ancho, double alto) {
        super(ancho, alto);
    }

    @Override
    public double calcularArea() {
        return ancho * alto;
    }
}
