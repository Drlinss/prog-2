/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MSI
 */
package practicaoop;

import java.util.ArrayList;
import java.util.List;

public class Clase {
    private String id;
    private List<Estudiante> estudiantes;
    private List<Profesor> profesores;

    public Clase(String id) {
        this.id = id;
        this.estudiantes = new ArrayList<>();
        this.profesores = new ArrayList<>();
    }

    public void agregarEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    public void agregarProfesor(Profesor profesor) {
        profesores.add(profesor);
    }

    public void mostrarInfo() {
        System.out.println("Clase ID: " + id);
        System.out.println("Estudiantes:");
        for (Estudiante estudiante : estudiantes) {
            estudiante.mostrarInfo();
        }
        System.out.println("Profesores:");
        for (Profesor profesor : profesores) {
            profesor.mostrarInfo();
        }
    }
}

