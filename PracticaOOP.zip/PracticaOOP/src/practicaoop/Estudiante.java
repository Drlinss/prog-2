/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MSI
 */
package practicaoop;

public class Estudiante extends Persona {
    private String numeroUnico;

    public Estudiante(String nombre, String numeroUnico) {
        super(nombre);
        this.numeroUnico = numeroUnico;
    }

    public String getNumeroUnico() {
        return numeroUnico;
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Estudiante: " + getNombre() + ", Número único: " + numeroUnico);
    }
}
