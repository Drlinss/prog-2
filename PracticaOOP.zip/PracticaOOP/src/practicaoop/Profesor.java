/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MSI
 */
package practicaoop;

import java.util.ArrayList;
import java.util.List;

public class Profesor extends Persona {
    private List<Curso> cursos;

    public Profesor(String nombre) {
        super(nombre);
        this.cursos = new ArrayList<>();
    }

    public void agregarCurso(Curso curso) {
        cursos.add(curso);
    }

    public List<Curso> getCursos() {
        return cursos;
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Profesor: " + getNombre() + ", Cursos: " + cursos.size());
    }
}
